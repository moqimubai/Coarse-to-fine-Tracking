function hf = train_filter_gpu(samplesf, yf, sample_weights, params)

% Do Conjugate gradient optimization of the filter.

sample_weights = permute(sample_weights, [2 3 4 1]);

% Construct the right hand side vector
rhs_samplef = cellfun(@(xf) sum(bsxfun(@times, sample_weights, xf), 4), samplesf, 'uniformoutput', false);
rhs_samplef = cellfun(@(xf, yf) bsxfun(@times, conj(xf), yf), rhs_samplef, yf, 'uniformoutput', false);

sample_energy = cellfun(@(xlf) abs(xlf .* conj(xlf)), samplesf, 'uniformoutput', false);
sample_energy = cellfun(@(xl) sum(sum(bsxfun(@times, sample_weights, xl), 4),3), sample_energy, 'uniformoutput', false);
% do conjugate gradient
hf = cellfun(@(xf, energy) bsxfun(@rdivide, xf, energy+params.lambda), rhs_samplef, sample_energy, 'uniformoutput', false);