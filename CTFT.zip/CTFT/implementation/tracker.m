function results = tracker(params)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Get sequence info
[seq, im] = get_sequence_info(params.seq);
params = rmfield(params, 'seq');
if isempty(im)
    seq.rect_position = [];
    [seq, results] = get_sequence_results(seq);
    return;
end

% Init position
pos = seq.init_pos(:)';
target_sz = seq.init_sz(:)';
params.init_sz = target_sz;

% Feature settings
features = params.t_features;

% Set default parameters
params = init_default_params(params);

% Global feature parameters
if isfield(params, 't_global')
    global_fparams = params.t_global;
else
    global_fparams = [];
end
global_fparams.use_gpu = params.use_gpu;
global_fparams.gpu_id = params.gpu_id;

% Correct max number of samples
params.nSamples = min(params.nSamples, seq.num_frames);

% Define data types
if params.use_gpu
    params.data_type = zeros(1, 'single', 'gpuArray');
else
    params.data_type = zeros(1, 'single');
end
params.data_type_complex = complex(params.data_type);
global_fparams.data_type = params.data_type;

init_target_sz = target_sz;

% Check if color image
if size(im,3) == 3
    if all(all(im(:,:,1) == im(:,:,2)))
        is_color_image = false;
    else
        is_color_image = true;
    end
else
    is_color_image = false;
end

if size(im,3) > 1 && is_color_image == false
    im = im(:,:,1);
end

% Check if mexResize is available and show warning otherwise.
params.use_mexResize = true;
global_fparams.use_mexResize = true;
try
    [~] = mexResize(ones(5,5,3,'uint8'), [3 3], 'auto');
catch err
    warning('ECO:tracker', 'Error when using the mexResize function. Using Matlab''s interpolation function instead, which is slower.\nTry to run the compile script in "external_libs/mexResize/".\n\nThe error was:\n%s', getReport(err));
    params.use_mexResize = false;
    global_fparams.use_mexResize = false;
end

% Calculate search area and initial scale factor
search_area = prod(init_target_sz * params.search_area_scale);
currentScaleFactor = sqrt(search_area / (224*224));

% target size at the initial scale
base_target_sz = target_sz / currentScaleFactor;

% window size, taking padding into account
switch params.search_area_shape
    case 'proportional'
        img_sample_sz = floor( base_target_sz * params.search_area_scale);     % proportional area, same aspect ratio as the target
    case 'square'
        img_sample_sz = repmat(sqrt(prod(base_target_sz * params.search_area_scale)), 1, 2); % square area, ignores the target aspect ratio
    case 'fix_padding'
        img_sample_sz = base_target_sz + sqrt(prod(base_target_sz * params.search_area_scale) + (base_target_sz(1) - base_target_sz(2))/4) - sum(base_target_sz)/2; % const padding
    case 'custom'
        img_sample_sz = [base_target_sz(1)*2 base_target_sz(2)*2]; % for testing
end

[features, global_fparams, feature_info] = init_features(features, global_fparams, is_color_image, img_sample_sz, 'same');

% Set feature info
img_support_sz = feature_info.img_support_sz;
feature_sz = feature_info.data_sz;
feature_sz(1,:) = ceil(base_target_sz) + mod( ceil(base_target_sz)+1, 2);
feature_dim = feature_info.dim;
num_feature_blocks = length(feature_dim);

% Get feature specific parameters
feature_params = init_feature_params(features, feature_info);
feature_extract_info = get_feature_extract_info(features);

% Set the sample feature dimension
if params.use_projection_matrix
    sample_dim = feature_params.compressed_dim;
else
    sample_dim = feature_dim;
end

% Size of the extracted feature maps
feature_sz_cell = permute(mat2cell(feature_sz, ones(1,num_feature_blocks), 2), [2 3 1]);

% Number of Fourier coefficients to save for each filter layer. This will
% be an odd number.
% filter_sz = feature_sz + mod(feature_sz+1, 2);
% filter_sz_cell = permute(mat2cell(filter_sz, ones(1,num_feature_blocks), 2), [2 3 1]);
% filter_sz_cell = filter_sz_cell(1);

filter_sz = feature_sz(1,:);
filter_sz_cell = permute(mat2cell(filter_sz, ones(1,1), 2), [2 3 1]);

% Compute the Fourier series indices and their transposes
ky = cellfun(@(sz) (-ceil((sz(1) - 1)/2) : floor((sz(1) - 1)/2))', filter_sz_cell, 'uniformoutput', false);
kx = cellfun(@(sz) -ceil((sz(2) - 1)/2) : 0, filter_sz_cell, 'uniformoutput', false);

sig_y = sqrt(prod(floor(base_target_sz))) * params.output_sigma_factor * (base_target_sz ./ img_support_sz);
yf_y = cellfun(@(ky) single(sqrt(2*pi) * sig_y(1) /filter_sz(1) * exp(-2 * (pi * sig_y(1) * ky /filter_sz(1)).^2)), ky, 'uniformoutput', false);
yf_x = cellfun(@(kx) single(sqrt(2*pi) * sig_y(2) / filter_sz(2) * exp(-2 * (pi * sig_y(2) * kx / filter_sz(2)).^2)), kx, 'uniformoutput', false);
yf = cellfun(@(yf_y, yf_x) cast(yf_y * yf_x, 'like', params.data_type), yf_y, yf_x, 'uniformoutput', false);

% output_sigma = sqrt(prod(base_target_sz/2)) * params.output_sigma_factor;
% yf_y = exp(-0.5 * (((ky{1}.^2) / output_sigma^2)));
% yf_x = exp(-0.5 * (((kx{1}.^2) / output_sigma^2)));
% y = fftshift(full_fourier_coeff(yf_y * yf_x));
% yf = {compact_fourier_coeff(cfft2(y))};




% construct cosine window
cos_window = cellfun(@(sz) hann(sz(1)+2)*hann(sz(2)+2)', feature_sz_cell, 'uniformoutput', false);
cos_window = cellfun(@(cos_window) cast(cos_window(2:end-1,2:end-1), 'like', params.data_type), cos_window, 'uniformoutput', false);

[interp1_fs, interp2_fs] = cellfun(@(sz) get_interp_fourier(sz, params), filter_sz_cell, 'uniformoutput', false);

if params.use_scale_filter
    [nScales, scale_step, scaleFactors, scale_filter, params] = init_scale_filter(params);
else
    % Use the translation filter to estimate the scale.
    nScales = params.number_of_scales;
    scale_step = params.scale_step;
    scale_exp = (-floor((nScales-1)/2):ceil((nScales-1)/2));
    scaleFactors = scale_step .^ scale_exp;
end

if nScales > 0
    %force reasonable scale changes
    min_scale_factor = scale_step ^ ceil(log(max(5 ./ img_support_sz)) / log(scale_step));
    max_scale_factor = scale_step ^ floor(log(min([size(im,1) size(im,2)] ./ base_target_sz)) / log(scale_step));
end

seq.time = 0;

% Initialize and allocate
prior_weights = zeros(params.nSamples,1, 'single');
sample_weights = cast(prior_weights, 'like', params.data_type);
samplesf = cell(1, 1, num_feature_blocks-1);
if params.use_gpu
    % In the GPU version, the data is stored in a more normal way since we
    % dont have to use mtimesx.
    for k = 1:num_feature_blocks-1
        samplesf{k} = zeros(filter_sz(k,1),(filter_sz(k,2)+1)/2,sample_dim(k),params.nSamples, 'like', params.data_type_complex);
    end
else
    for k = 1:num_feature_blocks-1
        samplesf{k} = zeros(params.nSamples,sample_dim(k),filter_sz(k,1),(filter_sz(k,2)+1)/2, 'like', params.data_type_complex);
    end
end

% Allocate
scores_fs_feat = cell(1,1,num_feature_blocks-1);

% Distance matrix stores the square of the euclidean distance between each pair of
% samples. Initialise it to inf
distance_matrix = inf(params.nSamples, 'single');

% Kernel matrix, used to update distance matrix
gram_matrix = inf(params.nSamples, 'single');

latest_ind = [];
frames_since_last_train = inf;
num_training_samples = 0;

% Find the minimum allowed sample weight. Samples are discarded if their weights become lower 
params.minimum_sample_weight = params.learning_rate*(1-params.learning_rate)^(2*params.nSamples);

res_norms = [];
residuals_pcg = [];

vert_delta = zeros(1,params.number_of_scales);
horiz_delta = zeros(1,params.number_of_scales);
while true
    % Read image
    if seq.frame > 0
        [seq, im] = get_sequence_frame(seq);
        if isempty(im)
            break;
        end
        if size(im,3) > 1 && is_color_image == false
            im = im(:,:,1);
        end
    else
        seq.frame = 1;
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Target localization step
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Do not estimate translation and scaling on the first frame, since we 
    % just want to initialize the tracker there
    if seq.frame > 1
        tic();
        old_pos = inf(size(pos));
        iter = 1;
        
        %translation search
        while iter <= params.refinement_iterations && any(old_pos ~= pos)
            % Extract features at multiple resolutions
            sample_pos = round(pos);
            det_sample_pos = sample_pos;
            sample_scale = currentScaleFactor*scaleFactors;
            
            xt = extract_features(im, sample_pos, sample_scale, features, global_fparams, feature_extract_info);
            xt_proj(2) = project_sample(xt(2), projection_matrix(2));
            xt_proj(2) = cellfun(@(feat_map, cos_window) bsxfun(@times, feat_map, cos_window), xt_proj(2), cos_window(2), 'uniformoutput', false);
            
            for s = 1:params.number_of_scales
                feat = imResample(gather(xt_proj{2}(:,:,:,s)),[27,27]);
                net_online.eval({'input1',gpuArray(feat),'input2',gpuArray(feat1st)});  
                response_map=gather(net_online.vars(10).value);    
                response = response_map .* motion_map;
                [vert_delta(s), horiz_delta(s)] = find(response == max(response(:)), 1);
                vert_delta(s)  = vert_delta(s)  - 14;
                horiz_delta(s) = horiz_delta(s) - 14;  
                %xt_proj_crop{1}(:,:,:,s) = xt{1}(55-(filter_sz(1)-1)/2+4*vert_delta(s):55+(filter_sz(1)-1)/2+4*vert_delta(s),55-(filter_sz(2)-1)/2+4*horiz_delta(s):55+(filter_sz(2)-1)/2+4*horiz_delta(s),:,s);
                xt_proj_crop{1}(:,:,:,s) = sample_patch(xt{1}(:,:,:,s), [55+4*vert_delta(s),55+4*horiz_delta(s)], filter_sz, filter_sz, global_fparams);
                %xt_proj_crop{1}(:,:,:,s) = xt{1}(29+4*vert_delta(s):81+4*vert_delta(s),29+4*horiz_delta(s):81+4*horiz_delta(s),:,s);
            end
            
            xt_proj_crop = cellfun(@(feat_map, cos_window) bsxfun(@times, feat_map, cos_window), xt_proj_crop, cos_window(1), 'uniformoutput', false);
            xtf_proj_crop = cellfun(@cfft2, xt_proj_crop, 'uniformoutput', false);
            xtf_proj_crop = interpolate_dft(xtf_proj_crop, interp1_fs, interp2_fs);
            scores_fs_sum = sum(bsxfun(@times, hf_full{1}, xtf_proj_crop{1}), 3);    
            scores_fs = permute(gather(scores_fs_sum),[1,2,4,3]);
            
            % Optimize the continuous score function with Newton's method.
            [trans_row, trans_col, scale_ind] = optimize_scores(scores_fs, params.newton_iterations);
            
            % Compute the translation vector in pixel-coordinates and round
            % to the closest integer pixel.
%             if seq.frame<25
%                 translation_vec = ([vert_delta(scale_ind), horiz_delta(scale_ind)]*8)* currentScaleFactor * scaleFactors(scale_ind);
%             else
%                 translation_vec = ([trans_row, trans_col] * 2+ [vert_delta(scale_ind), horiz_delta(scale_ind)]*8)* currentScaleFactor * scaleFactors(scale_ind);
%             end
            %translation_vec = ([trans_row, trans_col] * 2+ [vert_delta(scale_ind), horiz_delta(scale_ind)]*8)* currentScaleFactor * scaleFactors(scale_ind);
            %translation_vec = ([trans_row, trans_col] * 2)* currentScaleFactor * scaleFactors(scale_ind);
            translation_vec = ([vert_delta(scale_ind), horiz_delta(scale_ind)]*8)* currentScaleFactor * scaleFactors(scale_ind);
            scale_change_factor = scaleFactors(scale_ind);
            
           if mod(seq.frame,10)==0
           labelU=circshift(label,[vert_delta(scale_ind),horiz_delta(scale_ind)]);
                 feat_update{1} = imResample(gather(xt_proj{2}(:,:,:,scale_ind)),[27,27]);
                 label_update{1}=labelU; 
                 opts.train.gpus=1;
                 bopts.useGpu = numel(opts.train.gpus) > 0 ;
                 input={feat_update feat1st label_update};
                  info = cnn_train_dag_update(net_online, Updateimdb, input,getBatchWrapper(bopts), ...
                                     UpdatetrainOpts, ...
                                     'train', Updatetrain, ...                     
                                     opts.train) ;        
           end
            % update position
            old_pos = pos;
            pos = sample_pos + translation_vec;
            if params.clamp_position
                pos = max([1 1], min([size(im,1) size(im,2)], pos));
            end
            
            % Do scale tracking with the scale filter
            if nScales > 0 && params.use_scale_filter
                scale_change_factor = scale_filter_track(im, pos, base_target_sz, currentScaleFactor, scale_filter, params);
            end 
            
            % Update the scale
            currentScaleFactor = currentScaleFactor * scale_change_factor;
            
            % Adjust to make sure we are not to large or to small
            if currentScaleFactor < min_scale_factor
                currentScaleFactor = min_scale_factor;
            elseif currentScaleFactor > max_scale_factor
                currentScaleFactor = max_scale_factor;
            end
            
            iter = iter + 1;
        end
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Model update step
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
    % Extract sample and init projection matrix
    if seq.frame == 1
        % Extract image region for training sample
        sample_pos = round(pos);
        sample_scale = currentScaleFactor;
        xl = extract_features(im, sample_pos, currentScaleFactor, features, global_fparams, feature_extract_info);
        %xl{1} = xl{1}(55-(filter_sz(1)-1)/2:55+(filter_sz(1)-1)/2,55-(filter_sz(2)-1)/2:55+(filter_sz(2)-1)/2,:);
        xl{1} = sample_patch(xl{1}, [55,55], filter_sz, filter_sz, global_fparams);
        % Do windowing of features
        xlw = cellfun(@(feat_map, cos_window) bsxfun(@times, feat_map, cos_window), xl, cos_window, 'uniformoutput', false);
        projection_matrix = init_projection_matrix(xlw, sample_dim, params);
        xlw(2) = project_sample(xlw(2), projection_matrix(2));
        
        feat = imResample(gather(xlw{2}),[27,27]);
        % Compute the fourier series
        xlf = cellfun(@cfft2, xlw(1), 'uniformoutput', false);
        xlf = interpolate_dft(xlf, interp1_fs, interp2_fs);
        % New sample to be added
        xlf = compact_fourier_coeff(xlf);
        
        % Shift sample
        shift_samp = 2*pi * (pos - sample_pos) ./ (sample_scale * filter_sz*2);
        xlf_proj = shift_sample(xlf, shift_samp, kx, ky);
        
        % Init the projection matrix
        
        
        % Project sample
        
        target_sz1 = ceil(base_target_sz/params.cell_size);
        net_online=initNet(target_sz1);
        
        varargin=cell(1,2);

        varargin(1,1)={'train'};
        varargin(1,2)={struct('gpus', 1)};

        opts.expDir = 'exp/' ;
        opts.dataDir = 'exp/data/' ;
        opts.modelType = 'tracking' ;
        opts.sourceModelPath = 'exp/models/' ;
        [opts, varargin] = vl_argparse(opts, varargin) ;

        % experiment setup
        opts.imdbPath = fullfile(opts.expDir, 'imdb.mat') ;
        opts.imdbStatsPath = fullfile(opts.expDir, 'imdbStats.mat') ;
        opts.vocEdition = '11' ;
        opts.vocAdditionalSegmentations = false ;

        net_online.conserveMemory = false;
        trainOpts.numEpochs=200;
        trainOpts.batchSize = 1 ;
        trainOpts.numSubBatches = 1 ;
        trainOpts.continue = true ;
        trainOpts.gpus = 1 ;
        trainOpts.prefetch = true ;
        trainOpts.expDir = opts.expDir ;
        trainOpts.learningRate=5e-8;
        trainOpts.weightDecay= 1;
        
        train=1;
        imdb=[];
        output_sigma = target_sz1*0.1;
        label=gaussian_shaped_labels(output_sigma, [27,27]);
        motion_sigma = target_sz1*0.8;    
        motion_map=gaussian_shaped_labels(motion_sigma, [27,27]);
        input={feat label};
        feat1st=feat;
        opts.train.gpus=1;
        bopts.useGpu = 1 ;
        net_online.move('gpu');
        info = cnn_train_dag_my(net_online, imdb, input,getBatchWrapper(bopts), ...
                     trainOpts, ...
                     'train', train, ...                     
                     opts.train) ;
        
        UpdatetrainOpts.batchSize = 1 ;
        UpdatetrainOpts.numSubBatches = 1 ;
        UpdatetrainOpts.continue = true ;
        UpdatetrainOpts.gpus = 1 ;
        UpdatetrainOpts.prefetch = true ;

        UpdatetrainOpts.expDir = 'exp/update/' ;
        UpdatetrainOpts.learningRate = 2e-9;        
        UpdatetrainOpts.weightDecay= 1;
        UpdatetrainOpts.numEpochs = 5;

        Updatetrain=1;
        Updateimdb=[];
        
        tic();
    elseif params.learning_rate > 0
        if ~params.use_detection_sample
            % Extract image region for training sample
            sample_pos = round(pos);
            sample_scale = currentScaleFactor;
            xl = extract_features(im, sample_pos, currentScaleFactor, features, global_fparams, feature_extract_info);
            
            % Project sample
            xl_proj = project_sample(xl, projection_matrix);
            
            % Do windowing of features
            xl_proj = cellfun(@(feat_map, cos_window) bsxfun(@times, feat_map, cos_window), xl_proj, cos_window, 'uniformoutput', false);
            
            % Compute the fourier series
            xlf1_proj = cellfun(@cfft2, xl_proj, 'uniformoutput', false);
            
            % Interpolate features to the continuous domain
            xlf1_proj = interpolate_dft(xlf1_proj, interp1_fs, interp2_fs);
            
            % New sample to be added
            xlf_proj = compact_fourier_coeff(xlf1_proj);
        else
            if params.debug
                % Only for visualization
                xl = cellfun(@(xt) xt(:,:,:,scale_ind), xt, 'uniformoutput', false);
            end
            
            % Use the sample that was used for detection
            sample_scale = currentScaleFactor;
            xlf_proj = cellfun(@(xf) xf(:,1:(size(xf,2)+1)/2,:,scale_ind), xtf_proj_crop, 'uniformoutput', false);
        end
        
        % Shift the sample so that the target is centered
        shift_samp = 2*pi * (pos - sample_pos -[vert_delta(scale_ind), horiz_delta(scale_ind)]*8 *sample_scale) ./ (sample_scale * filter_sz*2);
        xlf_proj = shift_sample(xlf_proj, shift_samp, kx, ky);
    end
    
    % The permuted sample is only needed for the CPU implementation
    if ~params.use_gpu
        xlf_proj_perm = cellfun(@(xf) permute(xf, [4 3 1 2]), xlf_proj, 'uniformoutput', false);
    end
        
    if params.use_sample_merge
        % Update the samplesf to include the new sample. The distance
        % matrix, kernel matrix and prior weight are also updated
        if params.use_gpu
            [merged_sample, new_sample, merged_sample_id, new_sample_id, distance_matrix, gram_matrix, prior_weights] = ...
                update_sample_space_model_gpu(samplesf, xlf_proj, distance_matrix, gram_matrix, prior_weights,...
                num_training_samples,params);
        else
            [merged_sample, new_sample, merged_sample_id, new_sample_id, distance_matrix, gram_matrix, prior_weights] = ...
                update_sample_space_model(samplesf, xlf_proj_perm, distance_matrix, gram_matrix, prior_weights,...
                num_training_samples,params);
        end
        
        if num_training_samples < params.nSamples
            num_training_samples = num_training_samples + 1;
        end
    else
        % Do the traditional adding of a training sample and weight update
        % of C-COT
        [prior_weights, replace_ind] = update_prior_weights(prior_weights, gather(sample_weights), latest_ind, seq.frame, params);
        latest_ind = replace_ind;
        
        merged_sample_id = 0;
        new_sample_id = replace_ind;
        if params.use_gpu
            new_sample = xlf_proj;
        else
            new_sample = xlf_proj_perm;
        end
    end
    
    if seq.frame > 1 && params.learning_rate > 0 || seq.frame == 1 && ~params.update_projection_matrix
        % Insert the new training sample
        for k = 1:(num_feature_blocks-1)
            if params.use_gpu
                if merged_sample_id > 0
                    samplesf{k}(:,:,:,merged_sample_id) = merged_sample{k};
                end
                if new_sample_id > 0
                    samplesf{k}(:,:,:,new_sample_id) = new_sample{k};
                end
            else
                if merged_sample_id > 0
                    samplesf{k}(merged_sample_id,:,:,:) = merged_sample{k};
                end
                if new_sample_id > 0
                    samplesf{k}(new_sample_id,:,:,:) = new_sample{k};
                end
            end
        end
    end

    sample_weights = cast(prior_weights, 'like', params.data_type);
           
    train_tracker = (seq.frame < params.skip_after_frame) || (frames_since_last_train >= params.train_gap);
    
    if train_tracker     
            if params.use_gpu
                hf = train_filter_gpu(samplesf, yf, sample_weights, params);
            else
                [hf, res_norms, CG_state] = train_filter(hf, samplesf, yf, reg_filter, sample_weights, sample_energy, reg_energy, params, CG_opts, CG_state);
            end
        % Reconstruct the full Fourier series
        hf_full = full_fourier_coeff(hf);
        
        frames_since_last_train = 0;
    else
        frames_since_last_train = frames_since_last_train+1;
    end
    
    % Update the scale filter
    if nScales > 0 && params.use_scale_filter
        scale_filter = scale_filter_update(im, pos, base_target_sz, currentScaleFactor, scale_filter, params);
    end
    
    % Update the target size (only used for computing output box)
    target_sz = base_target_sz * currentScaleFactor;
    
    %save position and calculate FPS
    tracking_result.center_pos = double(pos);
    tracking_result.target_size = double(target_sz);
    seq = report_tracking_result(seq, tracking_result);
    
    seq.time = seq.time + toc();
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Visualization
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % debug visualization
    if params.debug
        figure(20)
%         set(gcf,'units','normalized','outerposition',[0 0 1 1]);
        subplot_cols = num_feature_blocks;
        subplot_rows = 3;%ceil(feature_dim/subplot_cols);
        for disp_layer = 1:num_feature_blocks;
            subplot(subplot_rows,subplot_cols,disp_layer);
            imagesc(mean(abs(sample_fs(conj(hf_full{disp_layer}))), 3)); 
            colorbar;
            axis image;
            subplot(subplot_rows,subplot_cols,disp_layer+subplot_cols);
            imagesc(mean(abs(xl{disp_layer}), 3)); 
            colorbar;
            axis image;
            if seq.frame > 1
                subplot(subplot_rows,subplot_cols,disp_layer+2*subplot_cols);
                imagesc(fftshift(sample_fs(scores_fs_feat{disp_layer}(:,:,1,scale_ind))));
                colorbar;
                axis image;
            end
        end
        
        if train_tracker
            residuals_pcg = [residuals_pcg; res_norms];
            res_start_ind = max(1, length(residuals_pcg)-300);
            figure(99);plot(res_start_ind:length(residuals_pcg), residuals_pcg(res_start_ind:end));
            axis([res_start_ind, length(residuals_pcg), 0, min(max(residuals_pcg(res_start_ind:end)), 0.2)]);
        end
    end
    
    % visualization
    if params.visualization
        rect_position_vis = [pos([2,1]) - (target_sz([2,1]) - 1)/2, target_sz([2,1])];
        
        im_to_show = double(im)/255;
        if size(im_to_show,3) == 1
            im_to_show = repmat(im_to_show, [1 1 3]);
        end
        if seq.frame == 1,  %first frame, create GUI
            fig_handle = figure('Name', 'Tracking');
%             set(fig_handle, 'Position', [100, 100, size(im,2), size(im,1)]);
            imagesc(im_to_show);
            hold on;
            rectangle('Position',rect_position_vis, 'EdgeColor','g', 'LineWidth',2);
            text(10, 10, int2str(seq.frame), 'color', [0 1 1]);
            hold off;
            axis off;axis image;set(gca, 'Units', 'normalized', 'Position', [0 0 1 1])
            
%             output_name = 'Video_name';
%             opengl software;
%             writer = VideoWriter(output_name, 'MPEG-4');
%             writer.FrameRate = 5;
%             open(writer);
        else
            % Do visualization of the sampled confidence scores overlayed
            resp_sz = round(img_support_sz*currentScaleFactor*scaleFactors(scale_ind));
            xs = floor(det_sample_pos(2)) + (1:resp_sz(2)) - floor(resp_sz(2)/2);
            ys = floor(det_sample_pos(1)) + (1:resp_sz(1)) - floor(resp_sz(1)/2);
            
            % To visualize the continuous scores, sample them 10 times more
            % dense than output_sz. 
            sampled_scores_display =fftshift(sample_fs(scores_fs(:,:,scale_ind)));
            
            figure(fig_handle);
%                 set(fig_handle, 'Position', [100, 100, 100+size(im,2), 100+size(im,1)]);
            imagesc(im_to_show);
            hold on;
            resp_handle = imagesc(xs, ys, sampled_scores_display); colormap hsv;
            alpha(resp_handle, 0.5);
            rectangle('Position',rect_position_vis, 'EdgeColor','g', 'LineWidth',2);
            text(10, 10, int2str(seq.frame), 'color', [0 1 1]);
            hold off;
            
%                 axis off;axis image;set(gca, 'Units', 'normalized', 'Position', [0 0 1 1])
        end
        
        drawnow
%         if frame > 1
%             if frame < inf
%                 writeVideo(writer, getframe(gcf));
%             else
%                 close(writer);
%             end
%         end
%          pause
    end
end

% close(writer);

[seq, results] = get_sequence_results(seq);

disp(['fps: ' num2str(results.fps)])
end

function fn = getBatchWrapper(opts)
% -------------------------------------------------------------------------
fn = @(imdb,batch) getBatch(imdb,batch,false,opts,'prefetch',nargout==0) ;
end
